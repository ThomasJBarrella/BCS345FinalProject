# BCS345FinalProject
Creating a card game that displays 4 random cards from the deck, adds their values together, and if the total is 24, the player wins.
